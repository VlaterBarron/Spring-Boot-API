package com.vladimir.studentform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentformApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentformApplication.class, args);
	}

}
